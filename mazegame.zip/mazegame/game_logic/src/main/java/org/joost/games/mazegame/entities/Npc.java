package org.joost.games.mazegame.entities;

public abstract class Npc {

    Tile tile;
    int damage;
    int health;


//    String getChar() {
//        return "b";
//    }

    abstract String getChar();

}
