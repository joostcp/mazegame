package org.joost.games.mazegame.entities;

public enum Direction {
    NORTH,
    EAST,
    SOUTH,
    WEST
}