package org.joost.games.mazegame.entities;

public interface FinishedListener {

    void finished( boolean hasWon );
}
